import json
import mysql.connector

# MySQL 연결 설정
conn = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='password',
    database='justice_ben'
)
cursor = conn.cursor()

# JSON 파일 읽기
with open('../user.json', encoding='utf-8') as f:
    data = json.load(f)

# 데이터 삽입
for item in data:
    role = item["role"].strip()  # \r 제거
    cursor.execute(
        "INSERT INTO user (email, password, role) VALUES (%s, %s, %s)",
        (item["email"], item["password"], role)
    )

conn.commit()
conn.close()