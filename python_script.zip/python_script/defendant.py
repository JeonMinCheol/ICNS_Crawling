import json
import mysql.connector

# MySQL 연결
conn = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='password',      # 🔁 비밀번호
    database='justice_ben'       # 🔁 DB 이름
)
cursor = conn.cursor()

# JSON 로드
with open('../defendant_lawyer.json', encoding='utf-8') as f:
    mappings = json.load(f)

# INSERT 반복
for row in mappings:
    result = row['RESULT'].strip()  # '\r' 제거
    cursor.execute("""
        INSERT INTO defendant_lawyer (_id, CASE_ID, LAWYER_NO, LAWYER_NAME, CLIENT_NAME, RESULT)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (
        row["_id"],
        row["CASE_ID"],
        row["LAWYER_NO"],
        row["LAWYER_NAME"],
        row["CLIENT_NAME"],
        result
    ))

conn.commit()
conn.close()
print("✅ 사건-변호사 매핑 정보 삽입 완료!")
