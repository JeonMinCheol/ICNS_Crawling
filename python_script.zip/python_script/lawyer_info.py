import json
import mysql.connector

# MySQL 연결
conn = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='password',      # 🔁 비밀번호
    database='justice_ben'       # 🔁 DB 이름
)
cursor = conn.cursor()

# JSON 로드
with open('../lawyer_info.json', encoding='utf-8') as f:
    lawyers = json.load(f)

# INSERT 반복
for lawyer in lawyers:
    cursor.execute("""
        INSERT INTO lawyer_info (_id, LAWYER_NAME, LAWFIRM, COUNT, WIN, LOSE)
        VALUES (%s, %s, %s, %s, %s, %s)
    """, (
        lawyer["_id"],
        lawyer["LAWYER_NAME"],
        lawyer["LAWFIRM"],
        lawyer["COUNT"],
        lawyer["WIN"],
        lawyer["LOSE"]
    ))

conn.commit()
conn.close()
print("✅ 변호사 정보 삽입 완료!")