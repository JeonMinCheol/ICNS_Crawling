import json
import mysql.connector
from datetime import datetime

# MySQL 연결 설정
conn = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='password',
    database='justice_ben'
)
cursor = conn.cursor()

# JSON 로드
with open('../case_info.json', encoding='utf-8') as f:
    cases = json.load(f)

# 반복하며 삽입
for case in cases:
    try:
        # 날짜 파싱
        decision_date = datetime.strptime(case['DECISION_DATE'], "%Y-%m-%d").date()
        # \r 제거
        result = case['RESULT'].strip()

        cursor.execute("""
            INSERT INTO case_info (
                CASE_ID, CASE_NAME, CASE_KIND, INCIDENT_REASON,
                COURT_NAME, INDEX_NO, SLIPOP_NO, JUDGE_NAME,
                PLAINTIFF_NAME, DEFENDANT_NAME, DECISION_DATE,
                PLAINTIFF_LAWYER_NUM, DEFENDANT_LAWYER_NUM, SUMMARY, RESULT
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            case["CASE_ID"],
            case["CASE_NAME"],
            case["CASE_KIND"],
            case["INCIDENT_REASON"],
            case["COURT_NAME"],
            case["INDEX_NO"],
            case["SLIPOP_NO"],
            case["JUDGE_NAME"],
            case["PLAINTIFF_NAME"],
            case["DEFENDANT_NAME"],
            decision_date,
            case["PLAINTIFF_LAWYER_NUM"],
            case["DEFENDANT_LAWYER_NUM"],
            case["SUMMARY"],
            result
        ))
    except Exception as e:
        print(f"❌ 오류 발생 (CASE_ID={case['CASE_ID']}):", e)

# 커밋 & 종료
conn.commit()
conn.close()
print("✅ 모든 데이터 삽입 완료!")
