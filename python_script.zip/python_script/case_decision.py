import json
import mysql.connector

# MySQL 연결 설정
conn = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='password',
    database='justice_ben'
)
cursor = conn.cursor()

# JSON 파일 읽기
with open('../case_decision.json', encoding='utf-8') as f:
    data = json.load(f)

# INSERT 수행 (_id 제외)
for row in data:
    paragraph = row['PARAGRAPH'].strip()  # '\r' 제거
    cursor.execute("""
        INSERT INTO case_decision (_id, CASE_ID, SENTENCE, PARAGRAPH)
        VALUES (%s, %s, %s, %s)
    """, (row['_id'], row['CASE_ID'], row['SENTENCE'], paragraph))

conn.commit()
conn.close()